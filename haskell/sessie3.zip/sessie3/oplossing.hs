-- Li Quan
-- 1e master computerwetenschappen ai
data Knoop a = Knoop a -- a = D [a] | M a | Z a

type D [a] = Knoop
type M [a] -> [a] = Knoop
type Z [a] -> [a] -> [a] = Knoop

data Net a  = [Knoop] [(Knoop,Knoop)] Int
